/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view.login;


public class main {
    public static void main(String[] args) {
    splashScreen main = new splashScreen();
    main.main(args);
    }
    
}
